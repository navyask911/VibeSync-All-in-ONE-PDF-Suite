package com.vibesync.toolkit.pdf

import com.vibesync.toolkit.pdf.core.util.PdfCoordinateMapper
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.ValueSource

@DisplayName("PdfCoordinateMapper Mathematical & Rotation Round-Trip Tests")
class PdfCoordinateMapperTest {

    private val tolerance = 0.05f

    // A4 Dimensions (Points)
    private val a4WidthPt = 595.28f
    private val a4HeightPt = 841.89f

    // Letter Dimensions (Points)
    private val letterWidthPt = 612f
    private val letterHeightPt = 792f

    // Display Canvas Size (Pixels)
    private val canvasWidthPx = 1080f
    private val canvasHeightPx = 1528f

    @ParameterizedTest(name = "A4 Portrait Round-Trip Conversion at {0} degrees")
    @ValueSource(ints = [0, 90, 180, 270])
    fun testA4PortraitRoundTrip(rotation: Int) {
        val mapper = PdfCoordinateMapper(
            pageWidthPt = a4WidthPt,
            pageHeightPt = a4HeightPt,
            canvasWidthPx = canvasWidthPx,
            canvasHeightPx = canvasHeightPx,
            rotationDegrees = rotation
        )

        val testScreenPoints = listOf(
            Pair(0f, 0f),                         // Top-Left
            Pair(canvasWidthPx, 0f),              // Top-Right
            Pair(0f, canvasHeightPx),             // Bottom-Left
            Pair(canvasWidthPx, canvasHeightPx),  // Bottom-Right
            Pair(canvasWidthPx / 2f, canvasHeightPx / 2f), // Center
            Pair(234.5f, 789.2f)                  // Arbitrary
        )

        for ((sx, sy) in testScreenPoints) {
            // Forward: Screen -> PDF
            val (pdfX, pdfY) = mapper.screenToPdf(sx, sy)

            // Inverse: PDF -> Screen
            val (recoveredSx, recoveredSy) = mapper.pdfToScreen(pdfX, pdfY)

            assertEquals(sx, recoveredSx, tolerance, "Screen X recovery failed at rotation $rotation")
            assertEquals(sy, recoveredSy, tolerance, "Screen Y recovery failed at rotation $rotation")
        }
    }

    @ParameterizedTest(name = "A4 Landscape Round-Trip Conversion at {0} degrees")
    @ValueSource(ints = [0, 90, 180, 270])
    fun testA4LandscapeRoundTrip(rotation: Int) {
        val mapper = PdfCoordinateMapper(
            pageWidthPt = a4HeightPt, // 841.89 (Width in landscape)
            pageHeightPt = a4WidthPt,  // 595.28 (Height in landscape)
            canvasWidthPx = 1528f,
            canvasHeightPx = 1080f,
            rotationDegrees = rotation
        )

        val testScreenPoints = listOf(
            Pair(0f, 0f),
            Pair(1528f, 0f),
            Pair(0f, 1080f),
            Pair(1528f, 1080f),
            Pair(764f, 540f),
            Pair(312.4f, 856.7f)
        )

        for ((sx, sy) in testScreenPoints) {
            val (pdfX, pdfY) = mapper.screenToPdf(sx, sy)
            val (recoveredSx, recoveredSy) = mapper.pdfToScreen(pdfX, pdfY)

            assertEquals(sx, recoveredSx, tolerance, "Screen X recovery failed for Landscape at rotation $rotation")
            assertEquals(sy, recoveredSy, tolerance, "Screen Y recovery failed for Landscape at rotation $rotation")
        }
    }

    @ParameterizedTest(name = "Letter Portrait Round-Trip Conversion at {0} degrees")
    @ValueSource(ints = [0, 90, 180, 270])
    fun testLetterPortraitRoundTrip(rotation: Int) {
        val mapper = PdfCoordinateMapper(
            pageWidthPt = letterWidthPt,
            pageHeightPt = letterHeightPt,
            canvasWidthPx = canvasWidthPx,
            canvasHeightPx = canvasHeightPx,
            rotationDegrees = rotation
        )

        val testScreenPoints = listOf(
            Pair(0f, 0f),
            Pair(canvasWidthPx, 0f),
            Pair(0f, canvasHeightPx),
            Pair(canvasWidthPx, canvasHeightPx),
            Pair(canvasWidthPx / 2f, canvasHeightPx / 2f)
        )

        for ((sx, sy) in testScreenPoints) {
            val (pdfX, pdfY) = mapper.screenToPdf(sx, sy)
            val (recoveredSx, recoveredSy) = mapper.pdfToScreen(pdfX, pdfY)

            assertEquals(sx, recoveredSx, tolerance, "Letter Screen X recovery failed at rotation $rotation")
            assertEquals(sy, recoveredSy, tolerance, "Letter Screen Y recovery failed at rotation $rotation")
        }
    }

    @Test
    @DisplayName("PDF-to-Screen-to-PDF Round-Trip Consistency")
    fun testPdfToScreenToPdfRoundTrip() {
        val mapper = PdfCoordinateMapper(
            pageWidthPt = a4WidthPt,
            pageHeightPt = a4HeightPt,
            canvasWidthPx = canvasWidthPx,
            canvasHeightPx = canvasHeightPx,
            rotationDegrees = 0
        )

        val testPdfPoints = listOf(
            Pair(0f, 0f),
            Pair(a4WidthPt, a4HeightPt),
            Pair(a4WidthPt / 2f, a4HeightPt / 2f),
            Pair(150.5f, 400.2f)
        )

        for ((px, py) in testPdfPoints) {
            val (sx, sy) = mapper.pdfToScreen(px, py)
            val (recoveredPx, recoveredPy) = mapper.screenToPdf(sx, sy)

            assertEquals(px, recoveredPx, tolerance, "PDF X recovery failed")
            assertEquals(py, recoveredPy, tolerance, "PDF Y recovery failed")
        }
    }
}
