package com.vibesync.toolkit.pdf.presentation.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import com.vibesync.toolkit.pdf.data.model.Point2D
import com.vibesync.toolkit.pdf.data.model.ToolMode
import com.vibesync.toolkit.pdf.data.model.VectorStroke

@Composable
fun VectorCanvasOverlay(
    toolMode: ToolMode,
    strokeColor: Color,
    strokeWidth: Float,
    existingStrokes: List<VectorStroke>,
    onStrokeAdded: (VectorStroke) -> Unit,
    onTap: (Offset) -> Unit,
    onEraseStroke: (Offset) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val currentPoints = remember { mutableStateListOf<Offset>() }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(toolMode, strokeColor, strokeWidth) {
                when (toolMode) {
                    ToolMode.PEN, ToolMode.HIGHLIGHTER -> {
                        detectDragGestures(
                            onDragStart = { offset ->
                                currentPoints.clear()
                                currentPoints.add(offset)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                currentPoints.add(change.position)
                            },
                            onDragEnd = {
                                if (currentPoints.size >= 2) {
                                    val isHighlighter = (toolMode == ToolMode.HIGHLIGHTER)
                                    val newStroke = VectorStroke(
                                        points = currentPoints.map { Point2D(it.x, it.y) },
                                        colorArgb = strokeColor.toArgb(),
                                        strokeWidth = if (isHighlighter) strokeWidth * 2.5f else strokeWidth,
                                        isHighlighter = isHighlighter
                                    )
                                    onStrokeAdded(newStroke)
                                }
                                currentPoints.clear()
                            },
                            onDragCancel = {
                                currentPoints.clear()
                            }
                        )
                    }
                    ToolMode.ERASER -> {
                        detectDragGestures(
                            onDragStart = { offset ->
                                onEraseStroke(offset)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                onEraseStroke(change.position)
                            },
                            onDragEnd = {},
                            onDragCancel = {}
                        )
                    }
                    ToolMode.TEXT -> {
                        detectTapGestures(
                            onTap = { offset ->
                                onTap(offset)
                            }
                        )
                    }
                    else -> {}
                }
            }
    ) {
        // 1. Render all existing baked/persisted strokes
        for (stroke in existingStrokes) {
            if (stroke.points.size >= 2) {
                val path = Path().apply {
                    val first = stroke.points.first()
                    moveTo(first.x, first.y)
                    for (i in 1 until stroke.points.size) {
                        val pt = stroke.points[i]
                        lineTo(pt.x, pt.y)
                    }
                }
                drawPath(
                    path = path,
                    color = Color(stroke.colorArgb).copy(alpha = stroke.alpha),
                    style = Stroke(
                        width = stroke.strokeWidth,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }

        // 2. Render actively drawn stroke in real time
        if (currentPoints.size >= 2) {
            val activePath = Path().apply {
                val first = currentPoints.first()
                moveTo(first.x, first.y)
                for (i in 1 until currentPoints.size) {
                    val pt = currentPoints[i]
                    lineTo(pt.x, pt.y)
                }
            }
            val isHighlighter = (toolMode == ToolMode.HIGHLIGHTER)
            drawPath(
                path = activePath,
                color = strokeColor.copy(alpha = if (isHighlighter) 0.35f else 1.0f),
                style = Stroke(
                    width = if (isHighlighter) strokeWidth * 2.5f else strokeWidth,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}
