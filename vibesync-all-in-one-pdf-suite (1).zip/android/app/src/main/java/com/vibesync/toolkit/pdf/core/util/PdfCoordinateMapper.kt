package com.vibesync.toolkit.pdf.core.util

/**
 * Mathematically precise coordinate mapper between Screen Display Pixels (Compose Canvas, Top-Left Origin)
 * and PDF User Points (72 DPI, Bottom-Left Cartesian Origin or rotated).
 */
data class PdfCoordinateMapper(
    val pageWidthPt: Float,
    val pageHeightPt: Float,
    val canvasWidthPx: Float,
    val canvasHeightPx: Float,
    val rotationDegrees: Int = 0
) {
    val normRotation: Int = ((rotationDegrees % 360) + 360) % 360

    val isTransposed: Boolean = (normRotation == 90 || normRotation == 270)

    // Effective visual points in display space
    val displayWidthPt: Float = if (isTransposed) pageHeightPt else pageWidthPt
    val displayHeightPt: Float = if (isTransposed) pageWidthPt else pageHeightPt

    val scaleX: Float = if (canvasWidthPx > 0f) displayWidthPt / canvasWidthPx else 1f
    val scaleY: Float = if (canvasHeightPx > 0f) displayHeightPt / canvasHeightPx else 1f

    /**
     * Maps screen canvas coordinates (0..canvasWidth, 0..canvasHeight, top-left origin)
     * to PDF points (0..pageWidth, 0..pageHeight, bottom-left origin).
     */
    fun screenToPdf(screenX: Float, screenY: Float): Pair<Float, Float> {
        val sx = screenX.coerceIn(0f, canvasWidthPx.coerceAtLeast(1f))
        val sy = screenY.coerceIn(0f, canvasHeightPx.coerceAtLeast(1f))

        return when (normRotation) {
            90 -> {
                // Screen X (0..W) maps along PDF height (pageHeightPt..0)
                // Screen Y (0..H) maps along PDF width (0..pageWidthPt)
                val pdfX = sy * (pageWidthPt / canvasHeightPx.coerceAtLeast(1f))
                val pdfY = pageHeightPt - (sx * (pageHeightPt / canvasWidthPx.coerceAtLeast(1f)))
                Pair(pdfX, pdfY)
            }
            180 -> {
                // Screen X (0..W) maps along PDF width (pageWidthPt..0)
                // Screen Y (0..H) maps along PDF height (0..pageHeightPt)
                val pdfX = pageWidthPt - (sx * (pageWidthPt / canvasWidthPx.coerceAtLeast(1f)))
                val pdfY = sy * (pageHeightPt / canvasHeightPx.coerceAtLeast(1f))
                Pair(pdfX, pdfY)
            }
            270 -> {
                // Screen X (0..W) maps along PDF height (0..pageHeightPt)
                // Screen Y (0..H) maps along PDF width (pageWidthPt..0)
                val pdfX = pageWidthPt - (sy * (pageWidthPt / canvasHeightPx.coerceAtLeast(1f)))
                val pdfY = sx * (pageHeightPt / canvasWidthPx.coerceAtLeast(1f))
                Pair(pdfX, pdfY)
            }
            else -> {
                // 0 degrees
                val pdfX = sx * (pageWidthPt / canvasWidthPx.coerceAtLeast(1f))
                val pdfY = pageHeightPt - (sy * (pageHeightPt / canvasHeightPx.coerceAtLeast(1f)))
                Pair(pdfX, pdfY)
            }
        }
    }

    /**
     * Maps PDF points (bottom-left origin) to screen canvas pixel coordinates (top-left origin).
     */
    fun pdfToScreen(pdfX: Float, pdfY: Float): Pair<Float, Float> {
        val px = pdfX.coerceIn(0f, pageWidthPt.coerceAtLeast(1f))
        val py = pdfY.coerceIn(0f, pageHeightPt.coerceAtLeast(1f))

        return when (normRotation) {
            90 -> {
                val screenX = (pageHeightPt - py) / (pageHeightPt / canvasWidthPx.coerceAtLeast(1f))
                val screenY = px / (pageWidthPt / canvasHeightPx.coerceAtLeast(1f))
                Pair(screenX, screenY)
            }
            180 -> {
                val screenX = (pageWidthPt - px) / (pageWidthPt / canvasWidthPx.coerceAtLeast(1f))
                val screenY = py / (pageHeightPt / canvasHeightPx.coerceAtLeast(1f))
                Pair(screenX, screenY)
            }
            270 -> {
                val screenX = py / (pageHeightPt / canvasWidthPx.coerceAtLeast(1f))
                val screenY = (pageWidthPt - px) / (pageWidthPt / canvasHeightPx.coerceAtLeast(1f))
                Pair(screenX, screenY)
            }
            else -> {
                val screenX = px / (pageWidthPt / canvasWidthPx.coerceAtLeast(1f))
                val screenY = (pageHeightPt - py) / (pageHeightPt / canvasHeightPx.coerceAtLeast(1f))
                Pair(screenX, screenY)
            }
        }
    }
}
