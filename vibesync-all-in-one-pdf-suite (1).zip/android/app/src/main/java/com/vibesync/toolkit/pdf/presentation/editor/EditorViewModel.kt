package com.vibesync.toolkit.pdf.presentation.editor

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vibesync.toolkit.pdf.core.security.SecurityVault
import com.vibesync.toolkit.pdf.core.util.UriUtils
import com.vibesync.toolkit.pdf.data.model.*
import com.vibesync.toolkit.pdf.data.pdf.PdfBoxToolkitEngine
import com.vibesync.toolkit.pdf.data.pdf.PdfRendererEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.hypot

data class EditorUiState(
    val currentPageIndex: Int = 0,
    val totalPages: Int = 1,
    val toolMode: ToolMode = ToolMode.PEN,
    val selectedColor: Color = Color(0xFFD32F2F),
    val strokeWidth: Float = 6f,
    val currentStrokes: List<VectorStroke> = emptyList(),
    val currentTextAnnotations: List<TextAnnotation> = emptyList(),
    val currentSignatures: List<SignatureAnnotation> = emptyList(),
    val pagesMetadata: List<PageMetadata> = emptyList(),
    val isSaving: Boolean = false,
    val exportSuccessFile: File? = null,
    val errorMessage: String? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false
) {
    val currentPageMetadata: PageMetadata?
        get() = pagesMetadata.getOrNull(currentPageIndex)

    val currentAspectRatio: Float
        get() = currentPageMetadata?.aspectRatio ?: (595f / 842f)
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val rendererEngine = PdfRendererEngine(application)
    private val toolkitEngine = PdfBoxToolkitEngine(application)
    private val securityVault = SecurityVault(application)

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var activeDocumentUri: Uri? = null
    private val pageAnnotationsMap = mutableMapOf<Int, PageAnnotations>()

    // Unified Command History per page
    private val undoStack = mutableListOf<AnnotationAction>()
    private val redoStack = mutableListOf<AnnotationAction>()

    fun initEditor(uri: Uri) {
        activeDocumentUri = uri
        viewModelScope.launch {
            rendererEngine.openDocument(uri).onSuccess { count ->
                val metadata = rendererEngine.getPagesMetadata()
                _uiState.value = _uiState.value.copy(
                    totalPages = count,
                    pagesMetadata = metadata
                )
                loadPageAnnotations(0)
            }
        }
    }

    suspend fun getPageBitmap(pageIndex: Int): Bitmap? {
        return rendererEngine.renderPage(pageIndex, scale = 1.5f)
    }

    fun selectTool(mode: ToolMode) {
        _uiState.value = _uiState.value.copy(toolMode = mode)
    }

    fun selectColor(color: Color) {
        _uiState.value = _uiState.value.copy(selectedColor = color)
    }

    fun setStrokeWidth(width: Float) {
        _uiState.value = _uiState.value.copy(strokeWidth = width)
    }

    fun addStroke(stroke: VectorStroke) {
        undoStack.add(AnnotationAction.AddStroke(stroke))
        redoStack.clear()
        val updated = _uiState.value.currentStrokes + stroke
        _uiState.value = _uiState.value.copy(
            currentStrokes = updated,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
        persistCurrentPageAnnotations()
    }

    fun eraseStrokeAt(point: Offset, thresholdPx: Float = 36f): Boolean {
        val strokes = _uiState.value.currentStrokes
        for (i in strokes.indices.reversed()) {
            val stroke = strokes[i]
            val hit = stroke.points.any { p ->
                hypot(p.x - point.x, p.y - point.y) <= (stroke.strokeWidth + thresholdPx)
            }
            if (hit) {
                undoStack.add(AnnotationAction.RemoveStroke(stroke))
                redoStack.clear()
                val updated = strokes.toMutableList().apply { removeAt(i) }
                _uiState.value = _uiState.value.copy(
                    currentStrokes = updated,
                    canUndo = undoStack.isNotEmpty(),
                    canRedo = redoStack.isNotEmpty()
                )
                persistCurrentPageAnnotations()
                return true
            }
        }
        return false
    }

    fun addTextAnnotation(text: String, x: Float, y: Float) {
        val annotation = TextAnnotation(
            x = x,
            y = y,
            text = text,
            fontSizeSp = 16f,
            colorArgb = _uiState.value.selectedColor.toArgb()
        )
        undoStack.add(AnnotationAction.AddText(annotation))
        redoStack.clear()
        val updated = _uiState.value.currentTextAnnotations + annotation
        _uiState.value = _uiState.value.copy(
            currentTextAnnotations = updated,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
        persistCurrentPageAnnotations()
    }

    fun addSignature(bitmap: Bitmap, x: Float, y: Float) {
        // Save to Hardware-backed Encrypted Vault
        securityVault.saveDefaultSignature(bitmap)

        val sig = SignatureAnnotation(
            x = x,
            y = y,
            width = 160f,
            height = 80f,
            bitmap = bitmap
        )
        undoStack.add(AnnotationAction.AddSignature(sig))
        redoStack.clear()
        val updated = _uiState.value.currentSignatures + sig
        _uiState.value = _uiState.value.copy(
            currentSignatures = updated,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
        persistCurrentPageAnnotations()
    }

    fun deleteSignature(signatureId: String) {
        val currentSigs = _uiState.value.currentSignatures
        val sigToDelete = currentSigs.find { it.id == signatureId } ?: return
        undoStack.add(AnnotationAction.RemoveSignature(sigToDelete))
        redoStack.clear()
        val updated = currentSigs.filter { it.id != signatureId }
        _uiState.value = _uiState.value.copy(
            currentSignatures = updated,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
        persistCurrentPageAnnotations()
    }

    fun updateSignatureTransform(signatureId: String, newX: Float, newY: Float, newWidth: Float? = null, newHeight: Float? = null) {
        val currentSigs = _uiState.value.currentSignatures
        val updated = currentSigs.map { sig ->
            if (sig.id == signatureId) {
                sig.copy(
                    x = newX,
                    y = newY,
                    width = newWidth ?: sig.width,
                    height = newHeight ?: sig.height
                )
            } else {
                sig
            }
        }
        _uiState.value = _uiState.value.copy(currentSignatures = updated)
        persistCurrentPageAnnotations()
    }

    fun commitSignatureMoveOrResize(oldSignature: SignatureAnnotation, newSignature: SignatureAnnotation) {
        if (oldSignature.x != newSignature.x || oldSignature.y != newSignature.y ||
            oldSignature.width != newSignature.width || oldSignature.height != newSignature.height) {
            undoStack.add(AnnotationAction.MoveOrResizeSignature(oldSignature, newSignature))
            redoStack.clear()
            _uiState.value = _uiState.value.copy(
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty()
            )
            persistCurrentPageAnnotations()
        }
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val action = undoStack.removeAt(undoStack.size - 1)
            redoStack.add(action)

            when (action) {
                is AnnotationAction.AddStroke -> {
                    val updated = _uiState.value.currentStrokes.filter { it.id != action.stroke.id }
                    _uiState.value = _uiState.value.copy(currentStrokes = updated)
                }
                is AnnotationAction.RemoveStroke -> {
                    val updated = _uiState.value.currentStrokes + action.stroke
                    _uiState.value = _uiState.value.copy(currentStrokes = updated)
                }
                is AnnotationAction.AddText -> {
                    val updated = _uiState.value.currentTextAnnotations.filter { it.id != action.textAnnotation.id }
                    _uiState.value = _uiState.value.copy(currentTextAnnotations = updated)
                }
                is AnnotationAction.RemoveText -> {
                    val updated = _uiState.value.currentTextAnnotations + action.textAnnotation
                    _uiState.value = _uiState.value.copy(currentTextAnnotations = updated)
                }
                is AnnotationAction.AddSignature -> {
                    val updated = _uiState.value.currentSignatures.filter { it.id != action.signature.id }
                    _uiState.value = _uiState.value.copy(currentSignatures = updated)
                }
                is AnnotationAction.RemoveSignature -> {
                    val updated = _uiState.value.currentSignatures + action.signature
                    _uiState.value = _uiState.value.copy(currentSignatures = updated)
                }
                is AnnotationAction.MoveOrResizeSignature -> {
                    val updated = _uiState.value.currentSignatures.map {
                        if (it.id == action.oldSignature.id) action.oldSignature else it
                    }
                    _uiState.value = _uiState.value.copy(currentSignatures = updated)
                }
            }

            _uiState.value = _uiState.value.copy(
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty()
            )
            persistCurrentPageAnnotations()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val action = redoStack.removeAt(redoStack.size - 1)
            undoStack.add(action)

            when (action) {
                is AnnotationAction.AddStroke -> {
                    val updated = _uiState.value.currentStrokes + action.stroke
                    _uiState.value = _uiState.value.copy(currentStrokes = updated)
                }
                is AnnotationAction.RemoveStroke -> {
                    val updated = _uiState.value.currentStrokes.filter { it.id != action.stroke.id }
                    _uiState.value = _uiState.value.copy(currentStrokes = updated)
                }
                is AnnotationAction.AddText -> {
                    val updated = _uiState.value.currentTextAnnotations + action.textAnnotation
                    _uiState.value = _uiState.value.copy(currentTextAnnotations = updated)
                }
                is AnnotationAction.RemoveText -> {
                    val updated = _uiState.value.currentTextAnnotations.filter { it.id != action.textAnnotation.id }
                    _uiState.value = _uiState.value.copy(currentTextAnnotations = updated)
                }
                is AnnotationAction.AddSignature -> {
                    val updated = _uiState.value.currentSignatures + action.signature
                    _uiState.value = _uiState.value.copy(currentSignatures = updated)
                }
                is AnnotationAction.RemoveSignature -> {
                    val updated = _uiState.value.currentSignatures.filter { it.id != action.signature.id }
                    _uiState.value = _uiState.value.copy(currentSignatures = updated)
                }
                is AnnotationAction.MoveOrResizeSignature -> {
                    val updated = _uiState.value.currentSignatures.map {
                        if (it.id == action.newSignature.id) action.newSignature else it
                    }
                    _uiState.value = _uiState.value.copy(currentSignatures = updated)
                }
            }

            _uiState.value = _uiState.value.copy(
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty()
            )
            persistCurrentPageAnnotations()
        }
    }

    fun setPage(index: Int) {
        persistCurrentPageAnnotations()
        _uiState.value = _uiState.value.copy(currentPageIndex = index)
        loadPageAnnotations(index)
    }

    private fun loadPageAnnotations(pageIndex: Int) {
        val annotations = pageAnnotationsMap[pageIndex] ?: PageAnnotations(pageIndex)
        undoStack.clear()
        redoStack.clear()

        _uiState.value = _uiState.value.copy(
            currentStrokes = annotations.strokes,
            currentTextAnnotations = annotations.textAnnotations,
            currentSignatures = annotations.signatures,
            canUndo = false,
            canRedo = false
        )
    }

    private fun persistCurrentPageAnnotations() {
        val current = _uiState.value
        pageAnnotationsMap[current.currentPageIndex] = PageAnnotations(
            pageIndex = current.currentPageIndex,
            strokes = current.currentStrokes,
            textAnnotations = current.currentTextAnnotations,
            signatures = current.currentSignatures
        )
    }

    /**
     * Bakes all vector strokes, highlighters, text, and signatures onto the PDF stream
     * using PdfBox at 72 DPI coordinate transformation.
     */
    fun saveFlattenedDocument(screenWidthPx: Float, onComplete: (File) -> Unit) {
        persistCurrentPageAnnotations()
        val sourceUri = activeDocumentUri ?: return
        _uiState.value = _uiState.value.copy(isSaving = true)

        viewModelScope.launch {
            val outputFile = UriUtils.createExportCacheFile(getApplication(), "signed_annotated")
            val result = toolkitEngine.flattenAnnotations(
                sourceUri = sourceUri,
                pageAnnotationsMap = pageAnnotationsMap,
                screenWidthPx = screenWidthPx,
                outputFile = outputFile
            )

            result.fold(
                onSuccess = { file ->
                    _uiState.value = _uiState.value.copy(isSaving = false, exportSuccessFile = file)
                    onComplete(file)
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isSaving = false,
                        errorMessage = error.localizedMessage ?: "Failed to flatten PDF"
                    )
                }
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        rendererEngine.closeDocument()
    }
}
