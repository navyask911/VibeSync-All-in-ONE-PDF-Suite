package com.vibesync.toolkit.pdf.presentation.editor

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vibesync.toolkit.pdf.core.designsystem.VibeSyncCrimsonPrimary

@Composable
fun SignaturePadDialog(
    onDismissRequest: () -> Unit,
    onSignatureCaptured: (Bitmap) -> Unit
) {
    val completedStrokes = remember { mutableStateListOf<List<Offset>>() }
    val currentStroke = remember { mutableStateListOf<Offset>() }
    var canvasSize by remember { mutableStateOf(IntSize(600, 300)) }

    Dialog(onDismissRequest = onDismissRequest) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Draw Digital Signature",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Sign with your finger or stylus in the box below",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Signature Drawing Canvas Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFAFAFA))
                        .border(
                            width = 1.5.dp,
                            color = Color(0xFFE0E0E0),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .onGloballyPositioned { coordinates ->
                            if (coordinates.size.width > 0 && coordinates.size.height > 0) {
                                canvasSize = coordinates.size
                            }
                        }
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        currentStroke.clear()
                                        currentStroke.add(offset)
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        currentStroke.add(change.position)
                                    },
                                    onDragEnd = {
                                        if (currentStroke.isNotEmpty()) {
                                            completedStrokes.add(currentStroke.toList())
                                        }
                                        currentStroke.clear()
                                    },
                                    onDragCancel = {
                                        currentStroke.clear()
                                    }
                                )
                            }
                    ) {
                        // Render previous completed strokes
                        for (stroke in completedStrokes) {
                            if (stroke.size >= 2) {
                                val path = Path().apply {
                                    moveTo(stroke.first().x, stroke.first().y)
                                    for (i in 1 until stroke.size) {
                                        lineTo(stroke[i].x, stroke[i].y)
                                    }
                                }
                                drawPath(
                                    path = path,
                                    color = Color(0xFF0F0404),
                                    style = Stroke(
                                        width = 4f,
                                        cap = StrokeCap.Round,
                                        join = StrokeJoin.Round
                                    )
                                )
                            }
                        }

                        // Render active drawing stroke
                        if (currentStroke.size >= 2) {
                            val activePath = Path().apply {
                                moveTo(currentStroke.first().x, currentStroke.first().y)
                                for (i in 1 until currentStroke.size) {
                                    lineTo(currentStroke[i].x, currentStroke[i].y)
                                }
                            }
                            drawPath(
                                path = activePath,
                                color = Color(0xFF0F0404),
                                style = Stroke(
                                    width = 4f,
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }

                    // Watermark / guideline indicator inside pad
                    if (completedStrokes.isEmpty() && currentStroke.isEmpty()) {
                        Text(
                            text = "Sign Here ✍️",
                            color = Color(0xFFBDBDBD),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            completedStrokes.clear()
                            currentStroke.clear()
                        },
                        enabled = completedStrokes.isNotEmpty() || currentStroke.isNotEmpty()
                    ) {
                        Text("Clear", color = Color(0xFFD32F2F))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismissRequest) {
                            Text("Cancel")
                        }

                        Button(
                            onClick = {
                                val width = canvasSize.width.coerceAtLeast(300)
                                val height = canvasSize.height.coerceAtLeast(150)
                                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                val androidCanvas = AndroidCanvas(bitmap)

                                val paint = AndroidPaint().apply {
                                    color = android.graphics.Color.BLACK
                                    style = AndroidPaint.Style.STROKE
                                    strokeWidth = 6f
                                    strokeCap = AndroidPaint.Cap.ROUND
                                    strokeJoin = AndroidPaint.Join.ROUND
                                    isAntiAlias = true
                                }

                                val allStrokes = completedStrokes.toList() + if (currentStroke.isNotEmpty()) listOf(currentStroke.toList()) else emptyList()
                                for (stroke in allStrokes) {
                                    if (stroke.size >= 2) {
                                        val androidPath = AndroidPath().apply {
                                            moveTo(stroke.first().x, stroke.first().y)
                                            for (i in 1 until stroke.size) {
                                                lineTo(stroke[i].x, stroke[i].y)
                                            }
                                        }
                                        androidCanvas.drawPath(androidPath, paint)
                                    }
                                }

                                onSignatureCaptured(bitmap)
                            },
                            enabled = completedStrokes.isNotEmpty() || currentStroke.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                        ) {
                            Text("Save & Apply")
                        }
                    }
                }
            }
        }
    }
}
