package com.vibesync.toolkit.pdf.presentation.tools

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.vibesync.toolkit.pdf.core.designsystem.VibeSyncCrimsonPrimary
import com.vibesync.toolkit.pdf.core.util.UriUtils
import com.vibesync.toolkit.pdf.data.pdf.PdfBoxToolkitEngine
import com.vibesync.toolkit.pdf.presentation.monetization.AdMobManager
import kotlinx.coroutines.launch
import java.io.File

// ==========================================
// 1. SPLIT PDF SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitScreen(
    onNavigateBack: () -> Unit,
    onSuccess: (List<File>) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val engine = remember { PdfBoxToolkitEngine(context) }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var intervalsInput by remember { mutableStateOf("1-2, 3") }
    var isProcessing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val pickPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> selectedUri = uri }

    val saveSplitDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri == null) return@rememberLauncherForActivityResult
        val uri = selectedUri ?: return@rememberLauncherForActivityResult
        isProcessing = true
        errorMessage = null
        coroutineScope.launch {
            val ranges = intervalsInput.split(",").mapNotNull { part ->
                val clean = part.trim()
                if (clean.contains("-")) {
                    val split = clean.split("-")
                    val start = split[0].toIntOrNull() ?: 1
                    val end = split[1].toIntOrNull() ?: start
                    IntRange(start, end)
                } else {
                    clean.toIntOrNull()?.let { IntRange(it, it) }
                }
            }

            val result = engine.splitPdf(uri, ranges)
            isProcessing = false
            result.fold(
                onSuccess = { files ->
                    val baseDoc = DocumentFile.fromTreeUri(context, treeUri)
                    val baseName = UriUtils.getFileName(context, uri).removeSuffix(".pdf")
                    var count = 0
                    files.forEachIndexed { idx, file ->
                        try {
                            val newDoc = baseDoc?.createFile("application/pdf", "${baseName}_part${idx + 1}.pdf")
                            newDoc?.uri?.let { destUri ->
                                context.contentResolver.openOutputStream(destUri)?.use { out ->
                                    file.inputStream().use { inStream ->
                                        inStream.copyTo(out)
                                    }
                                }
                                count++
                            }
                        } catch (e: Exception) {
                            android.util.Log.e("SplitScreen", "Error saving split piece to SAF directory", e)
                        }
                    }
                    android.widget.Toast.makeText(context, "Saved $count split files to selected folder", android.widget.Toast.LENGTH_LONG).show()
                    (context as? Activity)?.let { act ->
                        AdMobManager.showInterstitial(act) { onSuccess(files) }
                    } ?: onSuccess(files)
                },
                onFailure = { errorMessage = it.localizedMessage }
            )
        }
    }

    val saveSplitLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destinationUri: Uri? ->
        if (destinationUri == null) return@rememberLauncherForActivityResult
        val uri = selectedUri ?: return@rememberLauncherForActivityResult
        isProcessing = true
        errorMessage = null
        coroutineScope.launch {
            val ranges = intervalsInput.split(",").mapNotNull { part ->
                val clean = part.trim()
                if (clean.contains("-")) {
                    val split = clean.split("-")
                    val start = split[0].toIntOrNull() ?: 1
                    val end = split[1].toIntOrNull() ?: start
                    IntRange(start, end)
                } else {
                    clean.toIntOrNull()?.let { IntRange(it, it) }
                }
            }

            val result = engine.splitPdf(uri, ranges)
            isProcessing = false
            result.fold(
                onSuccess = { files ->
                    if (files.isNotEmpty()) {
                        try {
                            context.contentResolver.openOutputStream(destinationUri)?.use { outStream ->
                                files[0].inputStream().use { inStream ->
                                    inStream.copyTo(outStream)
                                }
                            }
                            android.widget.Toast.makeText(context, "Split file saved to chosen destination", android.widget.Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            android.util.Log.e("SplitScreen", "Error saving to destination", e)
                        }
                    }
                    (context as? Activity)?.let { act ->
                        AdMobManager.showInterstitial(act) { onSuccess(files) }
                    } ?: onSuccess(files)
                },
                onFailure = { errorMessage = it.localizedMessage }
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Split Document", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select PDF to Split", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (selectedUri != null) {
                        Text("Selected: ${UriUtils.getFileName(context, selectedUri!!)}", fontSize = 13.sp)
                    } else {
                        Button(
                            onClick = { pickPdfLauncher.launch(arrayOf("application/pdf")) },
                            colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                        ) {
                            Text("Choose PDF Document")
                        }
                    }
                }
            }

            OutlinedTextField(
                value = intervalsInput,
                onValueChange = { intervalsInput = it },
                label = { Text("Page Intervals (e.g. 1-2, 3, 4-5)") },
                modifier = Modifier.fillMaxWidth()
            )

            errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    val isMultiPart = intervalsInput.contains(",")
                    if (isMultiPart) {
                        saveSplitDirectoryLauncher.launch(null)
                    } else {
                        val baseName = UriUtils.getFileName(context, uri).removeSuffix(".pdf")
                        saveSplitLauncher.launch("Split_${baseName}_part1.pdf")
                    }
                },
                enabled = selectedUri != null && !isProcessing,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("Split and Save Files")
                }
            }
        }
    }
}

// ==========================================
// 2. MERGE PDFS SCREEN (Reorderable List)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MergeScreen(
    onNavigateBack: () -> Unit,
    onSuccess: (File) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val engine = remember { PdfBoxToolkitEngine(context) }

    val selectedUris = remember { mutableStateListOf<Uri>() }
    var isMerging by remember { mutableStateOf(false) }

    val pickMultiplePdfsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        selectedUris.addAll(uris)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Merge Documents", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Button(
                onClick = { pickMultiplePdfsLauncher.launch(arrayOf("application/pdf")) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add PDF Files to Merge")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Document Assembly Order:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(selectedUris) { index, uri ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${index + 1}.", fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                            Text(
                                UriUtils.getFileName(context, uri),
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                fontSize = 13.sp
                            )
                            // Up Arrow
                            IconButton(
                                onClick = {
                                    if (index > 0) {
                                        val temp = selectedUris[index]
                                        selectedUris[index] = selectedUris[index - 1]
                                        selectedUris[index - 1] = temp
                                    }
                                },
                                enabled = index > 0
                            ) {
                                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move Up")
                            }
                            // Down Arrow
                            IconButton(
                                onClick = {
                                    if (index < selectedUris.size - 1) {
                                        val temp = selectedUris[index]
                                        selectedUris[index] = selectedUris[index + 1]
                                        selectedUris[index + 1] = temp
                                    }
                                },
                                enabled = index < selectedUris.size - 1
                            ) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move Down")
                            }
                            // Delete
                            IconButton(onClick = { selectedUris.removeAt(index) }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (selectedUris.size >= 2) {
                        isMerging = true
                        coroutineScope.launch {
                            val output = UriUtils.createExportCacheFile(context, "merged_output")
                            val result = engine.mergePdfs(selectedUris, output)
                            isMerging = false
                            result.onSuccess { mergedFile ->
                                (context as? Activity)?.let { act ->
                                    AdMobManager.showInterstitial(act) { onSuccess(mergedFile) }
                                } ?: onSuccess(mergedFile)
                            }
                        }
                    }
                },
                enabled = selectedUris.size >= 2 && !isMerging,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                if (isMerging) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("Merge (${selectedUris.size}) Documents")
                }
            }
        }
    }
}

// ==========================================
// 3. ENCRYPT & PROTECT SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EncryptScreen(
    onNavigateBack: () -> Unit,
    onSuccess: (File) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val engine = remember { PdfBoxToolkitEngine(context) }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var password by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var allowPrinting by remember { mutableStateOf(true) }
    var allowCopying by remember { mutableStateOf(false) }
    var isEncrypting by remember { mutableStateOf(false) }

    val pickPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> selectedUri = uri }

    val saveProtectedPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destinationUri: Uri? ->
        if (destinationUri == null) return@rememberLauncherForActivityResult
        val uri = selectedUri ?: return@rememberLauncherForActivityResult
        isEncrypting = true
        coroutineScope.launch {
            val output = UriUtils.createExportCacheFile(context, "encrypted_protected")
            val result = engine.encryptPdf(
                sourceUri = uri,
                userPassword = password,
                ownerPassword = password + "_admin",
                allowPrinting = allowPrinting,
                allowCopying = allowCopying,
                outputFile = output
            )
            isEncrypting = false
            result.onSuccess { encFile ->
                try {
                    context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                        encFile.inputStream().use { inStream ->
                            inStream.copyTo(out)
                        }
                    }
                    android.widget.Toast.makeText(context, "Protected PDF saved to chosen location", android.widget.Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    android.util.Log.e("EncryptScreen", "Error saving to destination", e)
                }
                (context as? Activity)?.let { act ->
                    AdMobManager.showInterstitial(act) { onSuccess(encFile) }
                } ?: onSuccess(encFile)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Encrypt & Protect", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { pickPdfLauncher.launch(arrayOf("application/pdf")) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                Text(if (selectedUri != null) "Change PDF (${UriUtils.getFileName(context, selectedUri!!)})" else "Select PDF to Protect")
            }

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Document Password") },
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    val description = if (passwordVisible) "Hide password" else "Show password"
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = description)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = allowPrinting, onCheckedChange = { allowPrinting = it })
                Text("Allow Printing Document", fontSize = 14.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = allowCopying, onCheckedChange = { allowCopying = it })
                Text("Allow Content Copying / Extraction", fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    val baseName = UriUtils.getFileName(context, uri).removeSuffix(".pdf")
                    saveProtectedPdfLauncher.launch("Protected_${baseName}.pdf")
                },
                enabled = selectedUri != null && password.isNotBlank() && !isEncrypting,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                if (isEncrypting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("Apply AES-128/256 Encryption")
                }
            }
        }
    }
}

// ==========================================
// 4. CONVERT IMAGES TO PDF SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConvertImagesScreen(
    onNavigateBack: () -> Unit,
    onSuccess: (File) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val engine = remember { PdfBoxToolkitEngine(context) }

    val imageUris = remember { mutableStateListOf<Uri>() }
    var isConverting by remember { mutableStateOf(false) }
    var showSourceSheet by remember { mutableStateOf(false) }
    var cameraPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val pickGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        imageUris.addAll(uris)
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success && cameraPhotoUri != null) {
            imageUris.add(cameraPhotoUri!!)
        }
    }

    val saveConvertedPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destinationUri: Uri? ->
        if (destinationUri == null) return@rememberLauncherForActivityResult
        isConverting = true
        coroutineScope.launch {
            val tempFile = UriUtils.createExportCacheFile(context, "images_converted")
            val result = engine.convertImagesToPdf(imageUris.toList(), tempFile)
            isConverting = false
            result.onSuccess { pdfFile ->
                try {
                    context.contentResolver.openOutputStream(destinationUri)?.use { outStream ->
                        pdfFile.inputStream().use { inStream ->
                            inStream.copyTo(outStream)
                        }
                    }
                    android.widget.Toast.makeText(context, "Images converted and saved successfully!", android.widget.Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    android.util.Log.e("ConvertImagesScreen", "Failed writing to SAF", e)
                }
                (context as? Activity)?.let { act ->
                    AdMobManager.showInterstitial(act) { onSuccess(pdfFile) }
                } ?: onSuccess(pdfFile)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Images to PDF", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Button(
                onClick = { showSourceSheet = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Photos (Camera / Gallery)")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Selected Photos (${imageUris.size}):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            if (imageUris.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No photos added yet", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text("Tap above to snap camera photos or pick from gallery", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(imageUris) { index, uri ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${index + 1}.", fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                                Text(
                                    UriUtils.getFileName(context, uri),
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    fontSize = 13.sp
                                )
                                IconButton(onClick = { imageUris.removeAt(index) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red)
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    saveConvertedPdfLauncher.launch("Photos_${System.currentTimeMillis()}.pdf")
                },
                enabled = imageUris.isNotEmpty() && !isConverting,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
            ) {
                if (isConverting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("Generate & Save PDF (${imageUris.size} Pages)")
                }
            }
        }
    }

    // Source Selection Modal (Camera vs Gallery)
    if (showSourceSheet) {
        AlertDialog(
            onDismissRequest = { showSourceSheet = false },
            title = { Text("Select Photo Source", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Choose how you would like to add images:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(
                        onClick = {
                            showSourceSheet = false
                            try {
                                val cachePhotoFile = File(context.cacheDir, "camera_snap_${System.currentTimeMillis()}.jpg")
                                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", cachePhotoFile)
                                cameraPhotoUri = uri
                                takePictureLauncher.launch(uri)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Camera error: ${e.message}", android.widget.Toast.SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Capture with Camera")
                    }

                    OutlinedButton(
                        onClick = {
                            showSourceSheet = false
                            pickGalleryLauncher.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Choose from Gallery / Photos")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSourceSheet = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==========================================
// 5. EXTRACT IMAGES FROM PDF SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractImagesScreen(
    onNavigateBack: () -> Unit,
    onSuccess: (List<File>) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val engine = remember { PdfBoxToolkitEngine(context) }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var isExtracting by remember { mutableStateOf(false) }
    val extractedFiles = remember { mutableStateListOf<File>() }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val pickPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        selectedUri = uri
        extractedFiles.clear()
        errorMessage = null
    }

    val saveImagesDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri == null) return@rememberLauncherForActivityResult
        var savedCount = 0
        val baseDoc = DocumentFile.fromTreeUri(context, treeUri)
        extractedFiles.forEach { file ->
            try {
                val mime = if (file.extension.equals("jpg", ignoreCase = true)) "image/jpeg" else "image/png"
                val newDoc = baseDoc?.createFile(mime, file.name)
                newDoc?.uri?.let { destUri ->
                    context.contentResolver.openOutputStream(destUri)?.use { out ->
                        file.inputStream().use { inStream ->
                            inStream.copyTo(out)
                        }
                    }
                    savedCount++
                }
            } catch (e: Exception) {
                android.util.Log.e("ExtractImagesScreen", "Failed writing to SAF", e)
            }
        }
        android.widget.Toast.makeText(context, "Saved $savedCount images to chosen folder!", android.widget.Toast.LENGTH_LONG).show()
    }

    fun saveToDeviceGallery() {
        var count = 0
        extractedFiles.forEach { file ->
            try {
                val isJpg = file.extension.equals("jpg", ignoreCase = true)
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Images.Media.MIME_TYPE, if (isJpg) "image/jpeg" else "image/png")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VibeSyncPDF")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        file.inputStream().use { inStream ->
                            inStream.copyTo(out)
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                    }
                    count++
                }
            } catch (e: Exception) {
                android.util.Log.e("ExtractImagesScreen", "Failed saving to gallery", e)
            }
        }
        android.widget.Toast.makeText(context, "Saved $count images to Gallery!", android.widget.Toast.LENGTH_LONG).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Extract Images", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select PDF to Extract Images From", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (selectedUri != null) {
                        Text("Selected: ${UriUtils.getFileName(context, selectedUri!!)}", fontSize = 13.sp)
                    } else {
                        Button(
                            onClick = { pickPdfLauncher.launch(arrayOf("application/pdf")) },
                            colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                        ) {
                            Text("Choose PDF Document")
                        }
                    }
                }
            }

            if (selectedUri != null && extractedFiles.isEmpty() && !isExtracting) {
                Button(
                    onClick = {
                        val uri = selectedUri ?: return@Button
                        isExtracting = true
                        errorMessage = null
                        coroutineScope.launch {
                            val result = engine.extractEmbeddedImages(uri)
                            isExtracting = false
                            result.fold(
                                onSuccess = { files ->
                                    extractedFiles.addAll(files)
                                    if (files.isEmpty()) {
                                        errorMessage = "No raster images found in this PDF document."
                                    } else {
                                        android.widget.Toast.makeText(context, "Extracted ${files.size} images!", android.widget.Toast.SHORT).show()
                                    }
                                },
                                onFailure = {
                                    errorMessage = "Extraction failed: ${it.localizedMessage}"
                                }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                ) {
                    Text("Extract All Embedded Images")
                }
            }

            if (isExtracting) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = VibeSyncCrimsonPrimary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Scanning XObjects & extracting lossless images...", fontSize = 12.sp)
                    }
                }
            }

            errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            if (extractedFiles.isNotEmpty()) {
                Text("Extracted Images (${extractedFiles.size}):", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(extractedFiles) { index, file ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${index + 1}.", fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(file.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("${file.length() / 1024} KB", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { saveImagesDirectoryLauncher.launch(null) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save to Folder")
                    }

                    OutlinedButton(
                        onClick = { saveToDeviceGallery() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save to Gallery")
                    }
                }

                Button(
                    onClick = {
                        (context as? Activity)?.let { act ->
                            AdMobManager.showInterstitial(act) { onSuccess(extractedFiles.toList()) }
                        } ?: onSuccess(extractedFiles.toList())
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                ) {
                    Text("Done (${extractedFiles.size} images extracted)")
                }
            }
        }
    }
}
