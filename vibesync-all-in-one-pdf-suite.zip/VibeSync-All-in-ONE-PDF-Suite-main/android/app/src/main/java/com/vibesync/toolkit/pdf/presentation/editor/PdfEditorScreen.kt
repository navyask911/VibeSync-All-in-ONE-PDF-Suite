package com.vibesync.toolkit.pdf.presentation.editor

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibesync.toolkit.pdf.core.designsystem.VibeSyncCrimsonPrimary
import com.vibesync.toolkit.pdf.core.designsystem.VibeSyncRubyDeep
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.vibesync.toolkit.pdf.data.model.ToolMode
import com.vibesync.toolkit.pdf.presentation.monetization.AdMobManager
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfEditorScreen(
    documentUri: Uri,
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onExportComplete: (File) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val uiState by viewModel.uiState.collectAsState()

    var showSignatureDialog by remember { mutableStateOf(false) }
    var showTextInputDialog by remember { mutableStateOf(false) }
    var showPostSignDialog by remember { mutableStateOf(false) }
    var exportedSignedFile by remember { mutableStateOf<File?>(null) }
    var pendingTapOffset by remember { mutableStateOf(Offset.Zero) }
    var textInputState by remember { mutableStateOf("") }
    var canvasWidthPx by remember { mutableFloatStateOf(1080f) }
    var canvasHeightPx by remember { mutableFloatStateOf(1528f) }
    var selectedSignatureId by remember { mutableStateOf<String?>(null) }

    val saveToDeviceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destinationUri ->
        val fileToSave = exportedSignedFile
        if (destinationUri != null && fileToSave != null) {
            try {
                context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                    fileToSave.inputStream().use { input ->
                        input.copyTo(out)
                    }
                }
                Toast.makeText(context, "Saved successfully to device storage!", Toast.LENGTH_LONG).show()
                onExportComplete(fileToSave)
            } catch (e: Exception) {
                Toast.makeText(context, "Error saving file: ${e.message}", Toast.LENGTH_SHORT).show()
                onExportComplete(fileToSave)
            }
        } else if (fileToSave != null) {
            onExportComplete(fileToSave)
        }
    }

    LaunchedEffect(documentUri) {
        viewModel.initEditor(documentUri)
        AdMobManager.preloadInterstitial(context)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Annotate & Sign", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (uiState.totalPages > 1) {
                            Text(
                                "Page ${uiState.currentPageIndex + 1} of ${uiState.totalPages}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Page Navigation for Multi-page Documents
                    if (uiState.totalPages > 1) {
                        IconButton(
                            onClick = { if (uiState.currentPageIndex > 0) viewModel.setPage(uiState.currentPageIndex - 1) },
                            enabled = uiState.currentPageIndex > 0
                        ) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Page")
                        }
                        IconButton(
                            onClick = { if (uiState.currentPageIndex < uiState.totalPages - 1) viewModel.setPage(uiState.currentPageIndex + 1) },
                            enabled = uiState.currentPageIndex < uiState.totalPages - 1
                        ) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Next Page")
                        }
                    }

                    IconButton(onClick = { viewModel.undo() }, enabled = uiState.canUndo) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { viewModel.redo() }, enabled = uiState.canRedo) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo")
                    }
                    Button(
                        onClick = {
                            viewModel.saveFlattenedDocument(canvasWidthPx) { savedFile ->
                                (context as? Activity)?.let { activity ->
                                    AdMobManager.showInterstitial(activity) {
                                        exportedSignedFile = savedFile
                                        showPostSignDialog = true
                                    }
                                } ?: run {
                                    exportedSignedFile = savedFile
                                    showPostSignDialog = true
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                    ) {
                        if (uiState.isSaving) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Done, contentDescription = "Done", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Done")
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth().shadow(8.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Tool Palette Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ToolIconButton(
                            icon = Icons.Default.Edit,
                            label = "Pen",
                            isSelected = uiState.toolMode == ToolMode.PEN,
                            onClick = { viewModel.selectTool(ToolMode.PEN) }
                        )
                        ToolIconButton(
                            icon = Icons.Default.BorderColor,
                            label = "Highlighter",
                            isSelected = uiState.toolMode == ToolMode.HIGHLIGHTER,
                            onClick = { viewModel.selectTool(ToolMode.HIGHLIGHTER) }
                        )
                        ToolIconButton(
                            icon = Icons.Default.AutoFixHigh,
                            label = "Eraser",
                            isSelected = uiState.toolMode == ToolMode.ERASER,
                            onClick = { viewModel.selectTool(ToolMode.ERASER) }
                        )
                        ToolIconButton(
                            icon = Icons.Default.TextFields,
                            label = "Text",
                            isSelected = uiState.toolMode == ToolMode.TEXT,
                            onClick = { viewModel.selectTool(ToolMode.TEXT) }
                        )
                        ToolIconButton(
                            icon = Icons.Default.Draw,
                            label = "Sign",
                            isSelected = uiState.toolMode == ToolMode.SIGNATURE,
                            onClick = {
                                viewModel.selectTool(ToolMode.SIGNATURE)
                                showSignatureDialog = true
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Color Palette Selector (Only visible for drawing/text)
                    if (uiState.toolMode == ToolMode.PEN || uiState.toolMode == ToolMode.HIGHLIGHTER || uiState.toolMode == ToolMode.TEXT) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val palette = listOf(
                                Color(0xFFD32F2F), // Crimson Primary
                                Color(0xFF8E0000), // Deep Ruby
                                Color(0xFFC62828), // Crimson Dark
                                Color(0xFF1E88E5), // Blue
                                Color(0xFF43A047), // Green
                                Color(0xFFFDD835), // Highlighter Yellow
                                Color(0xFF120808)  // Dark Onyx
                            )

                            palette.forEach { color ->
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 6.dp)
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (uiState.selectedColor == color) 3.dp else 0.dp,
                                            color = if (uiState.selectedColor == color) Color.White else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable { viewModel.selectColor(color) }
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFCBD5E1)),
            contentAlignment = Alignment.Center
        ) {
            val pageBitmapState = produceState<Bitmap?>(initialValue = null, key1 = uiState.currentPageIndex) {
                value = viewModel.getPageBitmap(uiState.currentPageIndex)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .aspectRatio(uiState.currentAspectRatio)
                    .shadow(8.dp, RoundedCornerShape(4.dp))
                    .background(Color.White)
                    .onGloballyPositioned { coordinates ->
                        canvasWidthPx = coordinates.size.width.toFloat()
                        canvasHeightPx = coordinates.size.height.toFloat()
                    }
            ) {
                val bitmap = pageBitmapState.value
                if (bitmap != null && !bitmap.isRecycled) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "PDF Page Canvas",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }

                // Render placed text annotations
                for (textItem in uiState.currentTextAnnotations) {
                    val textOffsetX = with(density) { textItem.x.toDp() }
                    val textOffsetY = with(density) { textItem.y.toDp() }
                    Text(
                        text = textItem.text,
                        color = Color(textItem.colorArgb),
                        fontSize = textItem.fontSizeSp.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.offset(x = textOffsetX, y = textOffsetY)
                    )
                }

                // Render placed signatures with selection, drag-to-move, delete, and resize support
                for (sig in uiState.currentSignatures) {
                    sig.bitmap?.let { sigBmp ->
                        val sigOffsetX = with(density) { sig.x.toDp() }
                        val sigOffsetY = with(density) { sig.y.toDp() }
                        val sigWidthDp = with(density) { sig.width.toDp() }
                        val sigHeightDp = with(density) { sig.height.toDp() }
                        val isSelected = (selectedSignatureId == sig.id)

                        Box(
                            modifier = Modifier
                                .offset(x = sigOffsetX, y = sigOffsetY)
                                .size(width = sigWidthDp, height = sigHeightDp)
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.dp,
                                    color = if (isSelected) VibeSyncCrimsonPrimary else Color.Transparent,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { selectedSignatureId = if (isSelected) null else sig.id }
                                .pointerInput(sig.id) {
                                    var initialSig = sig
                                    var currentPosX = sig.x
                                    var currentPosY = sig.y
                                    detectDragGestures(
                                        onDragStart = {
                                            selectedSignatureId = sig.id
                                            initialSig = sig
                                            currentPosX = sig.x
                                            currentPosY = sig.y
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            currentPosX = (currentPosX + dragAmount.x).coerceIn(0f, (canvasWidthPx - sig.width).coerceAtLeast(0f))
                                            currentPosY = (currentPosY + dragAmount.y).coerceIn(0f, (canvasHeightPx - sig.height).coerceAtLeast(0f))
                                            viewModel.updateSignatureTransform(sig.id, currentPosX, currentPosY)
                                        },
                                        onDragEnd = {
                                            val currentSig = uiState.currentSignatures.find { it.id == sig.id }
                                            if (currentSig != null) {
                                                viewModel.commitSignatureMoveOrResize(initialSig, currentSig)
                                            }
                                        }
                                    )
                                }
                        ) {
                            Image(
                                bitmap = sigBmp.asImageBitmap(),
                                contentDescription = "Placed Signature",
                                modifier = Modifier.fillMaxSize()
                            )

                            // Delete Action Button on Selected Signature
                            if (isSelected) {
                                IconButton(
                                    onClick = {
                                        viewModel.deleteSignature(sig.id)
                                        selectedSignatureId = null
                                    },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .size(24.dp)
                                        .background(VibeSyncCrimsonPrimary, CircleShape)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Delete Signature",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                // Resize Handle at Bottom-End
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(20.dp)
                                        .background(VibeSyncCrimsonPrimary, CircleShape)
                                        .pointerInput(sig.id) {
                                            var initialSig = sig
                                            var currentWidth = sig.width
                                            var currentHeight = sig.height
                                            val aspectRatio = (sig.width / sig.height.coerceAtLeast(1f))
                                            detectDragGestures(
                                                onDragStart = {
                                                    initialSig = sig
                                                    currentWidth = sig.width
                                                    currentHeight = sig.height
                                                },
                                                onDrag = { change, dragAmount ->
                                                    change.consume()
                                                    currentWidth = (currentWidth + dragAmount.x).coerceIn(60f, canvasWidthPx * 0.8f)
                                                    currentHeight = (currentWidth / aspectRatio).coerceIn(30f, canvasHeightPx * 0.5f)
                                                    viewModel.updateSignatureTransform(
                                                        signatureId = sig.id,
                                                        newX = sig.x,
                                                        newY = sig.y,
                                                        newWidth = currentWidth,
                                                        newHeight = currentHeight
                                                    )
                                                },
                                                onDragEnd = {
                                                    val currentSig = uiState.currentSignatures.find { it.id == sig.id }
                                                    if (currentSig != null) {
                                                        viewModel.commitSignatureMoveOrResize(initialSig, currentSig)
                                                    }
                                                }
                                            )
                                        }
                                )
                            }
                        }
                    }
                }

                // Interactive Vector Canvas Overlay
                VectorCanvasOverlay(
                    toolMode = uiState.toolMode,
                    strokeColor = uiState.selectedColor,
                    strokeWidth = uiState.strokeWidth,
                    existingStrokes = uiState.currentStrokes,
                    onStrokeAdded = { stroke -> viewModel.addStroke(stroke) },
                    onEraseStroke = { offset -> viewModel.eraseStrokeAt(offset) },
                    onTap = { offset ->
                        if (uiState.toolMode == ToolMode.TEXT) {
                            pendingTapOffset = offset
                            showTextInputDialog = true
                        }
                    }
                )
            }
        }
    }

    // Signature Pad Modal Dialog
    if (showSignatureDialog) {
        SignaturePadDialog(
            onDismissRequest = { showSignatureDialog = false },
            onSignatureCaptured = { bitmap ->
                showSignatureDialog = false
                val initialX = (canvasWidthPx / 2f - 80f).coerceAtLeast(20f)
                val initialY = (canvasHeightPx / 2f - 40f).coerceAtLeast(20f)
                viewModel.addSignature(bitmap, x = initialX, y = initialY)
            }
        )
    }

    // Text Input Modal Dialog
    if (showTextInputDialog) {
        AlertDialog(
            onDismissRequest = { showTextInputDialog = false },
            title = { Text("Add Text Note") },
            text = {
                OutlinedTextField(
                    value = textInputState,
                    onValueChange = { textInputState = it },
                    placeholder = { Text("Enter annotation text...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (textInputState.isNotBlank()) {
                        viewModel.addTextAnnotation(textInputState, pendingTapOffset.x, pendingTapOffset.y)
                        textInputState = ""
                    }
                    showTextInputDialog = false
                }) {
                    Text("Place Text")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTextInputDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Post-Sign Export & Share Dialog (ACTION_SEND Chooser)
    if (showPostSignDialog && exportedSignedFile != null) {
        val fileToExport = exportedSignedFile!!
        AlertDialog(
            onDismissRequest = {
                showPostSignDialog = false
                onExportComplete(fileToExport)
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text("Signed Document Ready", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Your PDF document has been signed and flattened. Choose how you would like to proceed:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = VibeSyncCrimsonPrimary)
                            Text(
                                fileToExport.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPostSignDialog = false
                        try {
                            val contentUri = try {
                                FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    fileToExport
                                )
                            } catch (e: Exception) {
                                FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.provider",
                                    fileToExport
                                )
                            }
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, contentUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Signed PDF via..."))
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error sharing file: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                        onExportComplete(fileToExport)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VibeSyncCrimsonPrimary)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share Document")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showPostSignDialog = false
                        saveToDeviceLauncher.launch(fileToExport.name)
                    }
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save to Device")
                }
            }
        )
    }
}

@Composable
private fun ToolIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) VibeSyncCrimsonPrimary.copy(alpha = 0.12f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (isSelected) VibeSyncCrimsonPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) VibeSyncCrimsonPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
